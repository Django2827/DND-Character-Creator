import { useMemo, useState } from 'react'
import { useCharacter } from '../state/store'
import { getData } from '../rules/data'
import { buildCompendium } from '../rules/compendium'
import { loadPacks, savePack, removePack } from '../content/packs'
import { downloadFile } from '../lib/download'
import { KINDS, KIND_ORDER } from './kinds'
import { applyEntry, formFor, listEntries, newPack, removeEntry } from './ops'
import Fields from './fields'
import './PackEditor.css'

export default function PackEditor() {
  const packs = useCharacter((s) => s.packs)
  const setPacks = useCharacter((s) => s.setPacks)

  const [packId, setPackId] = useState(null)
  const [kindKey, setKindKey] = useState('spell')
  const [editing, setEditing] = useState(null) // { id: string | null, values }
  const [errors, setErrors] = useState([])
  const [creating, setCreating] = useState({ name: '', ruleset: '2024' })

  const pack = packs.find((p) => p.id === packId) ?? null
  const ctx = useMemo(() => {
    if (!pack) return null
    const compendium = buildCompendium([{ content: getData(pack.ruleset) }, ...packs], pack.ruleset)
    return { ruleset: pack.ruleset, compendium }
  }, [pack, packs])

  async function persist(next) {
    await savePack(next)
    setPacks(await loadPacks())
  }

  async function createPack() {
    if (!creating.name.trim()) return setErrors(['Give the pack a name.'])
    const next = newPack(creating.name, creating.ruleset, packs.map((p) => p.id))
    await persist(next)
    setPackId(next.id)
    setCreating({ ...creating, name: '' })
    setErrors([])
  }

  async function save() {
    const result = applyEntry(pack, kindKey, editing.values, ctx, editing.id)
    if (result.errors.length) return setErrors(result.errors)
    await persist(result.pack)
    setEditing(null)
    setErrors([])
  }

  async function deleteEntry(id) {
    if (!confirm('Delete this entry? Characters that use it will show it as missing.')) return
    await persist(removeEntry(pack, kindKey, id))
  }

  async function deletePack() {
    if (!confirm(`Delete the whole pack "${pack.name}"? Export it first if you want a backup.`)) return
    await removePack(pack.id)
    setPacks(await loadPacks())
    setPackId(null)
    setEditing(null)
  }

  const kind = KINDS[kindKey]

  return (
    <div className="builder">
      <section className="step">
        <h2>Homebrew &amp; content packs</h2>
        <p className="muted">
          Packs live only in this browser: they are never uploaded or put on the site. Export a pack to
          back it up or move it to another computer, and use &quot;Import content pack&quot; to load it there.
        </p>

        <div className="chips">
          <label style={{ display: 'inline' }}>
            Pack:{' '}
            <select value={packId ?? ''} onChange={(e) => { setPackId(e.target.value || null); setEditing(null) }}>
              <option value="">Choose…</option>
              {packs.map((p) => (
                <option key={p.id} value={p.id}>{p.name} ({p.ruleset ?? 'both'})</option>
              ))}
            </select>
          </label>
          {pack && (
            <>
              <button onClick={() => downloadFile(`${pack.id}.json`, JSON.stringify(pack, null, 2))}>Export pack</button>
              <button onClick={deletePack}>Delete pack</button>
            </>
          )}
        </div>

        <fieldset>
          <legend>New pack</legend>
          <input
            type="text"
            placeholder="Pack name"
            value={creating.name}
            onChange={(e) => setCreating({ ...creating, name: e.target.value })}
          />{' '}
          <select value={creating.ruleset} onChange={(e) => setCreating({ ...creating, ruleset: e.target.value })} aria-label="Ruleset">
            <option value="2024">2024 rules</option>
            <option value="2014">2014 rules</option>
          </select>{' '}
          <button onClick={createPack}>Create</button>
        </fieldset>
        {!editing && errors.length > 0 && <ul className="warn">{errors.map((e) => <li key={e}>{e}</li>)}</ul>}
      </section>

      {pack && (
        <section className="step" style={{ marginTop: 12 }}>
          <nav className="builder__nav" aria-label="Entry kinds">
            {KIND_ORDER.map((k) => (
              <button key={k} aria-current={k === kindKey ? 'step' : undefined} onClick={() => { setKindKey(k); setEditing(null); setErrors([]) }}>
                {KINDS[k].label}
              </button>
            ))}
          </nav>

          {!editing && (
            <>
              <button onClick={() => setEditing({ id: null, values: kind.blank(ctx) })}>New {kind.label.toLowerCase()}</button>
              {listEntries(pack, kindKey).length === 0 && <p className="muted">None in this pack yet.</p>}
              {listEntries(pack, kindKey).map(([id, entry]) => (
                <div key={id} className="listrow">
                  <span>{entry.name}</span>
                  <span>
                    <button onClick={() => setEditing({ id, values: formFor(pack, kindKey, id, ctx) })}>Edit</button>{' '}
                    <button onClick={() => deleteEntry(id)}>Delete</button>
                  </span>
                </div>
              ))}
            </>
          )}

          {editing && (
            <>
              <h3>{editing.id ? 'Edit' : 'New'} {kind.label.toLowerCase()}</h3>
              <Fields fields={kind.fields(ctx)} values={editing.values} onChange={(values) => setEditing({ ...editing, values })} />
              {errors.length > 0 && <ul className="warn">{errors.map((e) => <li key={e}>{e}</li>)}</ul>}
              <div className="builder__pager">
                <button onClick={save}>Save</button>
                <button onClick={() => { setEditing(null); setErrors([]) }}>Cancel</button>
              </div>
            </>
          )}
        </section>
      )}
    </div>
  )
}
