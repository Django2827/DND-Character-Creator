// Pure operations on a pack: create, add/replace an entry, remove an entry.
import { KINDS, slug } from './kinds'

export function newPack(name, ruleset, existingIds = []) {
  let id = slug(name)
  for (let n = 2; existingIds.includes(id); n++) id = `${slug(name)}-${n}`
  return { id, name: name.trim(), source: 'Homebrew', ruleset, content: {} }
}

export function listEntries(pack, kindKey) {
  return Object.entries(pack.content?.[KINDS[kindKey].section] ?? {}).sort((a, b) =>
    a[1].name.localeCompare(b[1].name)
  )
}

// ids must be unique across the whole pack (weapons, armor and gear share one lookup)
function uniqueId(pack, name) {
  const taken = new Set(Object.values(pack.content ?? {}).flatMap((entries) => Object.keys(entries)))
  const base = `${pack.id}:${slug(name)}`
  let id = base
  for (let n = 2; taken.has(id); n++) id = `${base}-${n}`
  return id
}

export function removeEntry(pack, kindKey, id) {
  const kind = KINDS[kindKey]
  const content = { ...pack.content }
  const entry = content[kind.section]?.[id]
  if (!entry) return pack
  const owned = kind.owned ? kind.owned(entry) : []

  const section = { ...content[kind.section] }
  delete section[id]
  content[kind.section] = section

  if (owned.length && content.features) {
    const features = { ...content.features }
    for (const fid of owned) delete features[fid]
    content.features = features
  }
  return { ...pack, content }
}

// ctx = { ruleset, compendium }. Returns { errors } or { pack, id, errors: [] }.
export function applyEntry(pack, kindKey, values, ctx, existingId = null) {
  const kind = KINDS[kindKey]
  const errors = kind.validate(values, ctx)
  if (errors.length) return { errors }

  const base = existingId ? removeEntry(pack, kindKey, existingId) : pack
  const id = existingId ?? uniqueId(base, values.name)
  const patch = kind.build(values, { ...ctx, id, packId: pack.id, ruleset: pack.ruleset })

  const content = { ...base.content }
  for (const [section, entries] of Object.entries(patch)) {
    content[section] = { ...(content[section] ?? {}), ...entries }
  }
  return { pack: { ...base, content }, id, errors: [] }
}

export function formFor(pack, kindKey, id, ctx) {
  const entry = pack.content[KINDS[kindKey].section][id]
  return KINDS[kindKey].fromEntry(entry, ctx, pack.content)
}
