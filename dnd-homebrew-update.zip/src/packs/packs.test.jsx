import { describe, it, expect } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import { KINDS, KIND_ORDER, makeSpellcasting } from './kinds'
import { applyEntry, formFor, listEntries, newPack, removeEntry } from './ops'
import Fields from './fields'
import Sheet from '../sheet/Sheet'
import { setup } from '../model/testUtils'
import { getRuleset } from '../rules'
import { getData } from '../rules/data'
import { buildCompendium } from '../rules/compendium'
import { derive } from '../model/derive'
import { findProblems } from '../model/problems'
import { characterPayload } from '../io/json'
import { PackSchema } from '../content/packs'
import { castableSpells } from '../model/spells'

const noop = () => {}
const ctxFor = (ruleset, packs = []) => ({
  ruleset,
  compendium: buildCompendium([{ content: getData(ruleset) }, ...packs], ruleset),
})

// minimal valid form values for each kind
const SAMPLES = (ruleset) => ({
  spell: { ...KINDS.spell.blank(), name: 'Frost Lance', level: 2, classes: [`${ruleset === '2014' ? 'srd51' : 'srd52'}:wizard`], concentration: true, damageDice: '3d8', damageType: 'Cold', desc: 'A lance of ice.', higherLevel: 'The damage increases by 1d8 for each slot level above 2.' },
  species: { ...KINDS.species.blank(), name: 'Stoneborn', speed: 25, hpPerLevel: 1, traits: [{ name: 'Rooted', desc: 'You are hard to move.' }], ...(ruleset === '2014' ? { abilityBonuses: { con: 2 }, languages: 'Common\nTerran' } : {}) },
  subspecies: { ...KINDS.subspecies.blank(), name: 'Cliffborn', parent: `${ruleset === '2014' ? 'srd51' : 'srd52'}:dwarf`, traits: [{ name: 'Climber', desc: 'Climbing is easy.' }], speedBonus: 5 },
  background: { ...KINDS.background.blank(), name: 'Lamplighter', skills: ['insight', 'stealth'], ...(ruleset === '2024' ? { abilityOptions: ['dex', 'wis', 'con'], originFeat: 'srd52:alert', equipment: 'A lantern' } : { featureName: 'City Lights', featureDesc: 'You know the streets.', equipment: 'A lantern\nOil' }) },
  feat: { ...KINDS.feat.blank(), name: 'Night Eyes', desc: 'You see well.', initiativeProf: true, hpPerLevel: 0 },
  class: { ...KINDS.class.blank(), name: 'Spellblade', hitDie: 10, saves: ['str', 'int'], skillChoose: 2, skillFrom: ['arcana', 'athletics', 'history'], proficiencies: 'Simple Weapons\nMartial Weapons\nLight Armor', subclassLevel: 3, castType: 'half', castAbility: 'int', features: [{ level: 1, name: 'Arcane Strike', desc: 'Channel magic.' }, { level: 3, name: 'Subclass', desc: 'Pick one.' }, { level: 5, name: 'Extra Attack', desc: 'Attack twice.' }] },
  subclass: { ...KINDS.subclass.blank(), name: 'Rune Knight Redux', class: `${ruleset === '2014' ? 'srd51' : 'srd52'}:fighter`, flavor: 'Runes.', features: [{ level: 3, name: 'Rune Carver', desc: 'Carve runes.' }, { level: 7, name: 'Giant Might', desc: 'Grow large.' }] },
  weapon: { ...KINDS.weapon.blank(), name: 'Gale Blade', damage: '1d8', damageType: 'Slashing', properties: ['Finesse', 'Light'], versatileDamage: '1d10' },
  armor: { ...KINDS.armor.blank(), name: 'Mooncloth', category: 'light', baseAc: 12 },
  gear: { ...KINDS.gear.blank(), name: 'Lamp Oil Flask', cost: '1 sp', desc: 'Burns for 6 hours.' },
})

describe.each(['2014', '2024'])('pack entries (%s rules)', (ruleset) => {
  const ctx = ctxFor(ruleset)
  const samples = SAMPLES(ruleset)

  it.each(KIND_ORDER)('%s: build, edit round-trip, and delete', (kindKey) => {
    const empty = newPack('Test Pack', ruleset)
    const created = applyEntry(empty, kindKey, samples[kindKey], ctx)
    expect(created.errors).toEqual([])
    expect(listEntries(created.pack, kindKey)).toHaveLength(1)
    expect(created.id.startsWith('test-pack:')).toBe(true)

    // opening the entry in the form and saving it unchanged must not change it
    const form = formFor(created.pack, kindKey, created.id, ctx)
    const resaved = applyEntry(created.pack, kindKey, form, ctx, created.id)
    expect(resaved.errors).toEqual([])
    expect(resaved.pack.content).toEqual(created.pack.content)

    // it must be valid pack data and survive JSON
    const parsed = PackSchema.parse(JSON.parse(JSON.stringify(created.pack)))
    expect(parsed.id).toBe('test-pack')

    // deleting removes it (and any features it owned)
    const removed = removeEntry(created.pack, kindKey, created.id)
    expect(listEntries(removed, kindKey)).toHaveLength(0)
    expect(Object.keys(removed.content.features ?? {})).toHaveLength(0)
  })

  it.each(KIND_ORDER)('%s: the form renders', (kindKey) => {
    const html = renderToStaticMarkup(
      <Fields fields={KINDS[kindKey].fields(ctx)} values={KINDS[kindKey].blank(ctx)} onChange={noop} />
    )
    expect(html).toContain('Name')
  })

  it('rejects an empty name and bad dice', () => {
    const pack = newPack('P', ruleset)
    expect(applyEntry(pack, 'spell', { ...KINDS.spell.blank() }, ctx).errors).toContain('Name is required.')
    expect(applyEntry(pack, 'spell', { ...samples.spell, damageDice: 'lots' }, ctx).errors.join()).toMatch(/Damage dice/)
    expect(applyEntry(pack, 'class', { ...samples.class, saves: ['str'] }, ctx).errors.join()).toMatch(/two saving throws/)
    expect(applyEntry(pack, 'subclass', { ...samples.subclass, class: '' }, ctx).errors.join()).toMatch(/class/)
  })

  it('duplicate names get unique ids', () => {
    let pack = newPack('P', ruleset)
    pack = applyEntry(pack, 'gear', samples.gear, ctx).pack
    const again = applyEntry(pack, 'gear', samples.gear, ctx)
    expect(listEntries(again.pack, 'gear').map(([id]) => id)).toEqual(['p:lamp-oil-flask', 'p:lamp-oil-flask-2'])
  })
})

describe('homebrew works end to end (2024)', () => {
  const ctx = ctxFor('2024')
  const samples = SAMPLES('2024')

  let pack = newPack('Homebrew', '2024')
  const ids = {}
  for (const kindKey of ['spell', 'species', 'subspecies', 'background', 'feat', 'class', 'subclass', 'weapon', 'armor']) {
    const r = applyEntry(pack, kindKey, samples[kindKey], ctx)
    expect(r.errors).toEqual([])
    pack = r.pack
    ids[kindKey] = r.id
  }
  // the new spell also goes on the new class's list
  pack = applyEntry(pack, 'spell', { ...samples.spell, classes: ['srd52:wizard', ids.class] }, ctx, ids.spell).pack

  const compendium = buildCompendium([{ content: getData('2024') }, pack], '2024')
  const character = {
    ...setup().character,
    name: 'Homebrew Hero',
    species: ids.species,
    background: ids.background,
    classes: [{ id: ids.class, subclass: null, level: 5 }],
    abilityScores: { str: 10, dex: 12, con: 14, int: 15, wis: 10, cha: 8 },
    originBonuses: { dex: 2, con: 1 },
    equipment: [
      { id: ids.weapon, equipped: true },
      { id: ids.armor, equipped: true },
    ],
    spells: { known: [], prepared: [ids.spell] },
  }
  const ruleset = getRuleset('2024')
  const stats = derive(character, ruleset, compendium)

  it('the new class, species and gear feed the calculations', () => {
    expect(stats.hitDice).toEqual({ 10: 5 })
    expect(stats.speed).toBe(25) // Stoneborn
    expect(stats.maxHp).toBe(10 + 2 + 4 * (6 + 2) + 5) // d10, +2 con, +1/level from Stoneborn
    expect(stats.ac).toBe(12 + 2) // Mooncloth + dex 14 (12 + 2)
    expect(stats.saves.int).toBe(2 + 3) // int 15 (+2) + proficiency 3, since the class lists the Int save
  })

  it('background skills and feat effects apply', () => {
    expect(stats.grantedSkills).toEqual(expect.arrayContaining(['insight', 'stealth']))
    expect(stats.initiative).toBe(2 + 3) // dex 14 (+2), Alert gives +prof (3)
  })

  it('half-caster slots, DC and spell limits come from the preset', () => {
    expect(stats.spell.slots).toEqual([4, 2]) // level 5 half caster, 2024 starts at level 1
    expect(stats.spell.saveDc).toBe(8 + 3 + 2)
    expect(stats.spell.limit).toBe(2 + 4) // 2 at level 1, +1 per level
    expect(castableSpells(character, stats, compendium).leveled).toEqual([ids.spell])
  })

  it('class features show on the sheet', () => {
    const names = stats.features.map((f) => f.name)
    expect(names).toEqual(expect.arrayContaining(['Arcane Strike', 'Subclass', 'Extra Attack', 'Rooted']))
    expect(names).not.toContain('Rune Carver') // subclass not picked yet
  })

  it('a homebrew subclass attaches to a built-in class', () => {
    const fighter = { ...character, classes: [{ id: 'srd52:fighter', subclass: ids.subclass, level: 7 }] }
    const s = derive(fighter, ruleset, compendium)
    const names = s.features.map((f) => f.name)
    expect(names).toEqual(expect.arrayContaining(['Rune Carver', 'Giant Might']))
    const subs = Object.entries(compendium.subclasses).filter(([, x]) => x.class === 'srd52:fighter')
    expect(subs.map(([id]) => id)).toContain(ids.subclass)
  })

  it('a homebrew lineage attaches to a built-in species', () => {
    const subs = Object.entries(compendium.subspecies).filter(([, x]) => x.parent === 'srd52:dwarf')
    expect(subs.map(([id]) => id)).toContain(ids.subspecies)
    const dwarf = { ...character, species: 'srd52:dwarf', subspecies: ids.subspecies }
    expect(derive(dwarf, ruleset, compendium).speed).toBe(30 + 5)
  })

  it('weapons from a pack get attacks with proficiency', () => {
    const atk = stats.attacks.find((a) => a.name === 'Gale Blade')
    expect(atk.ability).toBe('dex') // finesse, and dex (+2) beats str (+0)
    expect(atk.proficient).toBe(true) // the class lists Martial Weapons
    expect(atk.bonus).toBe(2 + 3)
    expect(atk.damage).toBe('1d8+2')
    expect(atk.versatile).toBe('1d10+2')
  })

  it('nothing is missing, and the export is self-contained', () => {
    expect(findProblems(character, compendium)).toEqual([])
    const payload = JSON.parse(JSON.stringify(characterPayload(character, compendium)))
    expect(payload.content.classes[ids.class]).toBeDefined()
    expect(payload.content.spells[ids.spell]).toBeDefined()
    expect(payload.content.species[ids.species]).toBeDefined()
    const lean = buildCompendium([{ content: payload.content }], '2024')
    expect(derive(payload, ruleset, lean)).toEqual(stats)
  })

  it('the sheet renders it', () => {
    const html = renderToStaticMarkup(
      <Sheet character={character} stats={stats} compendium={compendium} onStateChange={noop} />
    )
    expect(html).toContain('Homebrew Hero')
    expect(html).toContain('Frost Lance')
    expect(html).toContain('Gale Blade')
  })

  it('editing a class replaces its features instead of duplicating them', () => {
    const form = formFor(pack, 'class', ids.class, ctx)
    form.features = [{ level: 2, name: 'Only Feature', desc: 'x' }]
    const edited = applyEntry(pack, 'class', form, ctx, ids.class).pack
    const classFeatureIds = Object.keys(edited.content.features).filter((f) => f.startsWith(`${ids.class}-`))
    expect(classFeatureIds).toEqual([`${ids.class}-only-feature`])
    // the subclass features are untouched
    expect(edited.content.features[Object.keys(edited.content.features).find((f) => f.includes('rune-carver'))]).toBeDefined()
  })
})

describe('class spellcasting presets', () => {
  it('full, half and pact tables are right', () => {
    const base = { ...KINDS.class.blank(), castAbility: 'cha' }
    const full = makeSpellcasting({ ...base, castType: 'full' }, '2024')
    expect(full.slots[1]).toEqual([2])
    expect(full.slots[20]).toEqual([4, 3, 3, 3, 3, 2, 2, 1, 1])
    const half14 = makeSpellcasting({ ...base, castType: 'half' }, '2014')
    expect(half14.startLevel).toBe(2)
    expect(half14.slots[1]).toBeUndefined()
    expect(half14.slots[2]).toEqual([2])
    const pact = makeSpellcasting({ ...base, castType: 'pact' }, '2024')
    expect(pact.pact).toBe(true)
    expect(pact.slots[5]).toEqual([0, 0, 2])
    expect(pact.slots[17]).toEqual([0, 0, 0, 0, 4])
    expect(makeSpellcasting({ ...base, castType: 'none' }, '2024')).toBeNull()
  })

  it('2014 known casters get a known table; cantrips step up at 4 and 10', () => {
    const sc = makeSpellcasting({ ...KINDS.class.blank(), castType: 'full', castMode: 'known', known1: 2, knownPerLevel: 1, cantrips1: 2, cantrips4: 3, cantrips10: 4 }, '2014')
    expect(sc.mode).toBe('known')
    expect(sc.known[1]).toBe(2)
    expect(sc.known[5]).toBe(6)
    expect([sc.cantrips[1], sc.cantrips[4], sc.cantrips[10]]).toEqual([2, 3, 4])
  })
})
