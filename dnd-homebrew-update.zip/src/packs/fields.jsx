import { ABILITIES, ABILITY_NAMES } from '../rules/shared'

const same = (a, b) => String(a) === String(b)

function Input({ f, value, set }) {
  switch (f.type) {
    case 'textarea':
      return <textarea value={value ?? ''} onChange={(e) => set(e.target.value)} />
    case 'number':
      return (
        <input
          type="number"
          min={f.min}
          max={f.max}
          step="any"
          value={value ?? ''}
          onChange={(e) => set(e.target.value === '' ? '' : Number(e.target.value))}
        />
      )
    case 'checkbox':
      return <input type="checkbox" checked={!!value} onChange={(e) => set(e.target.checked)} />
    case 'select':
      return (
        <select value={value ?? ''} onChange={(e) => set(f.number ? Number(e.target.value) : e.target.value)}>
          {f.allowBlank && <option value="">Choose…</option>}
          {f.options.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
      )
    case 'multi':
      return (
        <span className="chips">
          {f.options.map((o) => (
            <label key={o.value} style={{ display: 'inline' }}>
              <input
                type="checkbox"
                checked={(value ?? []).some((v) => same(v, o.value))}
                onChange={(e) =>
                  set(e.target.checked ? [...(value ?? []), o.value] : (value ?? []).filter((v) => !same(v, o.value)))
                }
              />{' '}
              {o.label}
            </label>
          ))}
        </span>
      )
    case 'abilities':
      return (
        <span className="chips">
          {ABILITIES.map((a) => (
            <label key={a} style={{ display: 'inline' }}>
              {ABILITY_NAMES[a].slice(0, 3)}{' '}
              <input
                type="number"
                style={{ width: '3.5em' }}
                value={value?.[a] ?? ''}
                onChange={(e) => set({ ...(value ?? {}), [a]: e.target.value === '' ? '' : Number(e.target.value) })}
              />
            </label>
          ))}
        </span>
      )
    case 'rows':
      return (
        <div className="rows">
          {(value ?? []).map((row, i) => (
            <div key={i} className="rows__row">
              {f.columns.map((c) => (
                <label key={c.key} className={`rows__${c.key}`}>
                  <small>{c.label}</small>
                  {c.type === 'textarea' ? (
                    <textarea value={row[c.key] ?? ''} onChange={(e) => set(value.map((r, j) => (j === i ? { ...r, [c.key]: e.target.value } : r)))} />
                  ) : (
                    <input
                      type={c.type}
                      value={row[c.key] ?? ''}
                      onChange={(e) =>
                        set(value.map((r, j) => (j === i ? { ...r, [c.key]: c.type === 'number' && e.target.value !== '' ? Number(e.target.value) : e.target.value } : r)))
                      }
                    />
                  )}
                </label>
              ))}
              <button type="button" onClick={() => set(value.filter((_, j) => j !== i))}>Remove</button>
            </div>
          ))}
          <button type="button" onClick={() => set([...(value ?? []), f.blankRow()])}>Add row</button>
        </div>
      )
    default:
      return <input type="text" value={value ?? ''} onChange={(e) => set(e.target.value)} />
  }
}

export default function Fields({ fields, values, onChange }) {
  return fields
    .filter((f) => !f.show || f.show(values))
    .map((f) => (
      <div key={f.key} className="field">
        <label>
          <span className="field__label">{f.label}</span>
          {f.type !== 'multi' && f.type !== 'rows' && f.type !== 'abilities' && (
            <Input f={f} value={values[f.key]} set={(v) => onChange({ ...values, [f.key]: v })} />
          )}
        </label>
        {(f.type === 'multi' || f.type === 'rows' || f.type === 'abilities') && (
          <Input f={f} value={values[f.key]} set={(v) => onChange({ ...values, [f.key]: v })} />
        )}
        {f.help && <small className="muted">{f.help}</small>}
      </div>
    ))
}
