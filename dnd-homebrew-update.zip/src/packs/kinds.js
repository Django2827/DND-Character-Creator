// Every kind of entry you can create in a content pack: its form fields, how to turn
// the form into compendium entries (build), and how to turn an entry back into a form
// (fromEntry). Pure functions, so they're easy to test.
//
// build() returns a "patch": { section: { id: entry } }. Classes and subclasses also
// return a `features` section, because their level features are separate entries.

import { ABILITIES, ABILITY_NAMES, SKILLS, proficiencyBonus, titleCase } from '../rules/shared'

export const slug = (s) =>
  String(s ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'entry'

const lines = (text) =>
  String(text ?? '')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
const num = (v, fallback = 0) => {
  const n = Number(v)
  return v !== '' && v != null && Number.isFinite(n) ? n : fallback
}
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n))
const optStr = (s) => String(s ?? '').trim() || null
const trim = (s) => String(s ?? '').trim()

const opts = (entries) =>
  Object.entries(entries ?? {})
    .map(([value, e]) => ({ value, label: e.name }))
    .sort((a, b) => a.label.localeCompare(b.label))
const strOpts = (list) => list.map((v) => ({ value: v, label: v }))
const abilityOpts = ABILITIES.map((a) => ({ value: a, label: ABILITY_NAMES[a] }))
const skillOpts = Object.keys(SKILLS).map((s) => ({ value: s, label: titleCase(s) }))

const SCHOOLS = ['Abjuration', 'Conjuration', 'Divination', 'Enchantment', 'Evocation', 'Illusion', 'Necromancy', 'Transmutation']
const SIZES = ['Small', 'Medium', 'Small or Medium', 'Large']
const WEAPON_PROPERTIES = ['Ammunition', 'Finesse', 'Heavy', 'Light', 'Loading', 'Range', 'Reach', 'Special', 'Thrown', 'Two-Handed', 'Versatile']
const FEAT_TYPES = ['Origin', 'General', 'Fighting Style', 'Epic Boon']

const traitColumns = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'desc', label: 'Description', type: 'textarea' },
]
const blankTrait = () => ({ name: '', desc: '' })

// ---------- effects (numbers the sheet applies automatically) ----------
const effectFields = (withInitiativeProf = false) => [
  { key: 'hpPerLevel', label: 'Extra HP per level', type: 'number', help: 'e.g. 1 for Dwarven Toughness' },
  { key: 'speedBonus', label: 'Speed bonus (ft)', type: 'number' },
  { key: 'acBonus', label: 'AC bonus', type: 'number' },
  { key: 'initiativeBonus', label: 'Initiative bonus', type: 'number' },
  ...(withInitiativeProf
    ? [{ key: 'initiativeProf', label: 'Add proficiency bonus to initiative', type: 'checkbox' }]
    : []),
]
const blankEffects = () => ({ hpPerLevel: 0, speedBonus: 0, acBonus: 0, initiativeBonus: 0, initiativeProf: false })

function effectsFromValues(v) {
  const out = []
  if (num(v.hpPerLevel)) out.push({ type: 'hpPerLevel', value: num(v.hpPerLevel) })
  if (num(v.speedBonus)) out.push({ type: 'speed', value: num(v.speedBonus) })
  if (num(v.acBonus)) out.push({ type: 'acBonus', value: num(v.acBonus) })
  if (num(v.initiativeBonus)) out.push({ type: 'initiative', value: num(v.initiativeBonus) })
  if (v.initiativeProf) out.push({ type: 'initiativeProf' })
  return out
}

function effectsToValues(effects = []) {
  const v = blankEffects()
  for (const e of effects) {
    if (e.type === 'hpPerLevel') v.hpPerLevel = e.value
    if (e.type === 'speed') v.speedBonus = e.value
    if (e.type === 'acBonus') v.acBonus = e.value
    if (e.type === 'initiative') v.initiativeBonus = e.value
    if (e.type === 'initiativeProf') v.initiativeProf = true
  }
  return v
}

const cleanBonuses = (map) =>
  Object.fromEntries(Object.entries(map ?? {}).filter(([, v]) => num(v) !== 0).map(([k, v]) => [k, num(v)]))

const cleanRows = (rows, keep = 'name') => (rows ?? []).filter((r) => trim(r[keep]))
const needName = (v) => (trim(v.name) ? [] : ['Name is required.'])

// ---------- spellcasting tables for the class builder ----------
const FULL = [[2], [3], [4, 2], [4, 3], [4, 3, 2], [4, 3, 3], [4, 3, 3, 1], [4, 3, 3, 2], [4, 3, 3, 3, 1], [4, 3, 3, 3, 2], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1, 1], [4, 3, 3, 3, 2, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1, 1], [4, 3, 3, 3, 3, 1, 1, 1, 1], [4, 3, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 3, 2, 2, 1, 1]]
const HALF = [[2], [2], [3], [3], [4, 2], [4, 2], [4, 3], [4, 3], [4, 3, 2], [4, 3, 2], [4, 3, 3], [4, 3, 3], [4, 3, 3, 1], [4, 3, 3, 1], [4, 3, 3, 2], [4, 3, 3, 2], [4, 3, 3, 3, 1], [4, 3, 3, 3, 1], [4, 3, 3, 3, 2], [4, 3, 3, 3, 2]]
const PACT = [[1], [2], [0, 2], [0, 2], [0, 0, 2], [0, 0, 2], [0, 0, 0, 2], [0, 0, 0, 2], [0, 0, 0, 0, 2], [0, 0, 0, 0, 2], [0, 0, 0, 0, 3], [0, 0, 0, 0, 3], [0, 0, 0, 0, 3], [0, 0, 0, 0, 3], [0, 0, 0, 0, 3], [0, 0, 0, 0, 3], [0, 0, 0, 0, 4], [0, 0, 0, 0, 4], [0, 0, 0, 0, 4], [0, 0, 0, 0, 4]]
const SLOT_TABLES = { full: FULL, half: HALF, pact: PACT }

const CASTING_KEYS = [
  'castType', 'castAbility', 'castMode', 'preparedFormula', 'spellbook', 'startLevel',
  'cantrips1', 'cantrips4', 'cantrips10', 'known1', 'knownPerLevel', 'prepared1', 'preparedPerLevel',
]
const blankCasting = () => ({
  castType: 'none',
  castAbility: 'int',
  castMode: 'prepared',
  preparedFormula: 'full',
  spellbook: false,
  startLevel: '',
  cantrips1: 2,
  cantrips4: 3,
  cantrips10: 4,
  known1: 2,
  knownPerLevel: 1,
  prepared1: 2,
  preparedPerLevel: 1,
})

export function makeSpellcasting(v, ruleset) {
  if (v.castType === 'none' || !SLOT_TABLES[v.castType]) return null
  const is2014 = ruleset === '2014'
  const start = clamp(num(v.startLevel, v.castType === 'half' && is2014 ? 2 : 1), 1, 20)
  const mode = is2014 ? v.castMode : 'prepared'
  const sc = {
    ability: v.castAbility,
    startLevel: start,
    mode,
    spellbook: !!v.spellbook,
    pact: v.castType === 'pact',
    info: [],
    cantrips: {},
    known: {},
    prepared: {},
    slots: {},
  }
  if (is2014 && mode === 'prepared' && v.preparedFormula === 'half') sc.preparedFormula = 'half'
  for (let level = start; level <= 20; level++) {
    const slots = SLOT_TABLES[v.castType][level - 1]
    if (slots) sc.slots[level] = [...slots]
    sc.cantrips[level] = num(level >= 10 ? v.cantrips10 : level >= 4 ? v.cantrips4 : v.cantrips1)
    const grown = (base, per) => Math.max(0, Math.floor(num(base) + (level - start) * num(per)))
    if (is2014 && mode === 'known') sc.known[level] = grown(v.known1, v.knownPerLevel)
    if (!is2014) sc.prepared[level] = grown(v.prepared1, v.preparedPerLevel)
  }
  return sc
}

// ---------- feature rows (class and subclass level features) ----------
const featureColumns = [
  { key: 'level', label: 'Level', type: 'number' },
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'desc', label: 'Description', type: 'textarea' },
]
const blankFeature = () => ({ level: 1, name: '', desc: '' })

function makeFeatures(rows, ownerId, base) {
  const features = {}
  const ids = []
  const used = new Set()
  cleanRows(rows).forEach((r, i) => {
    let fid = `${ownerId}-${slug(r.name)}`
    if (used.has(fid)) fid += `-${i + 1}`
    used.add(fid)
    features[fid] = { ...base, name: trim(r.name), level: clamp(num(r.level, 1), 1, 20), desc: trim(r.desc) }
    ids.push(fid)
  })
  return { features, ids }
}

// ---------- the kinds ----------
export const KINDS = {
  spell: {
    label: 'Spell',
    section: 'spells',
    blank: () => ({
      name: '', level: 1, school: 'Evocation', classes: [], castingTime: '1 action', range: '60 feet',
      components: 'V, S', material: '', duration: 'Instantaneous', concentration: false, ritual: false,
      desc: '', higherLevel: '', damageDice: '', damageType: '',
    }),
    fields: ({ compendium }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'level', label: 'Level (0 = cantrip)', type: 'number', min: 0, max: 9 },
      { key: 'school', label: 'School', type: 'select', options: strOpts(SCHOOLS) },
      { key: 'classes', label: 'Class spell lists', type: 'multi', options: opts(compendium.classes) },
      { key: 'castingTime', label: 'Casting time', type: 'text' },
      { key: 'range', label: 'Range', type: 'text' },
      { key: 'components', label: 'Components', type: 'text', help: 'e.g. V, S, M' },
      { key: 'material', label: 'Material (if any)', type: 'text' },
      { key: 'duration', label: 'Duration', type: 'text' },
      { key: 'concentration', label: 'Concentration', type: 'checkbox' },
      { key: 'ritual', label: 'Ritual', type: 'checkbox' },
      { key: 'desc', label: 'Description', type: 'textarea' },
      { key: 'higherLevel', label: 'At higher levels', type: 'textarea', help: 'Write "increases by 1d6 for each slot level above 3" and the Dmg button will scale.' },
      { key: 'damageDice', label: 'Damage dice (optional)', type: 'text', help: 'e.g. 8d6. Adds a Dmg button to the cast row.' },
      { key: 'damageType', label: 'Damage type', type: 'text' },
    ],
    validate: (v) => [
      ...needName(v),
      ...(num(v.level) < 0 || num(v.level) > 9 ? ['Level must be 0 to 9.'] : []),
      ...(trim(v.damageDice) && !/^\d+d\d+$/.test(trim(v.damageDice)) ? ['Damage dice must look like 8d6.'] : []),
    ],
    build: (v, { id }) => ({
      spells: {
        [id]: {
          name: trim(v.name),
          level: clamp(num(v.level), 0, 9),
          school: v.school,
          classes: v.classes ?? [],
          castingTime: trim(v.castingTime),
          range: trim(v.range),
          components: trim(v.components),
          material: optStr(v.material),
          duration: trim(v.duration),
          concentration: !!v.concentration,
          ritual: !!v.ritual,
          desc: trim(v.desc),
          higherLevel: trim(v.higherLevel),
          ...(trim(v.damageDice)
            ? { damage: { type: trim(v.damageType) || 'Damage', bySlot: { [clamp(num(v.level), 0, 9)]: trim(v.damageDice) }, byLevel: null } }
            : {}),
        },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, level: e.level, school: e.school, classes: e.classes ?? [], castingTime: e.castingTime,
      range: e.range, components: e.components, material: e.material ?? '', duration: e.duration,
      concentration: !!e.concentration, ritual: !!e.ritual, desc: e.desc, higherLevel: e.higherLevel ?? '',
      damageDice: Object.values(e.damage?.bySlot ?? {})[0] ?? '', damageType: e.damage?.type ?? '',
    }),
  },

  species: {
    label: 'Species / race',
    section: 'species',
    blank: () => ({ name: '', size: 'Medium', speed: 30, abilityBonuses: {}, languages: '', skills: [], traits: [blankTrait()], ...blankEffects() }),
    fields: ({ ruleset }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'size', label: 'Size', type: 'select', options: strOpts(SIZES) },
      { key: 'speed', label: 'Speed (ft)', type: 'number' },
      ...(ruleset === '2014'
        ? [
            { key: 'abilityBonuses', label: 'Ability score increases', type: 'abilities' },
            { key: 'languages', label: 'Languages (one per line)', type: 'textarea' },
          ]
        : []),
      { key: 'skills', label: 'Skill proficiencies granted', type: 'multi', options: skillOpts },
      { key: 'traits', label: 'Traits', type: 'rows', columns: traitColumns, blankRow: blankTrait },
      ...effectFields(),
    ],
    validate: (v) => [...needName(v), ...(num(v.speed) < 0 ? ['Speed can\'t be negative.'] : [])],
    build: (v, { id, ruleset }) => ({
      species: {
        [id]: {
          name: trim(v.name),
          size: v.size,
          speed: num(v.speed, 30),
          traits: cleanRows(v.traits).map((t) => ({ name: trim(t.name), desc: trim(t.desc) })),
          subspecies: [],
          skills: v.skills ?? [],
          effects: effectsFromValues(v),
          ...(ruleset === '2014' ? { abilityBonuses: cleanBonuses(v.abilityBonuses), languages: lines(v.languages) } : {}),
        },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, size: e.size, speed: e.speed, abilityBonuses: e.abilityBonuses ?? {},
      languages: (e.languages ?? []).join('\n'), skills: e.skills ?? [],
      traits: e.traits?.length ? e.traits : [blankTrait()], ...effectsToValues(e.effects),
    }),
  },

  subspecies: {
    label: 'Subrace / lineage',
    section: 'subspecies',
    blank: () => ({ name: '', parent: '', abilityBonuses: {}, traits: [blankTrait()], ...blankEffects() }),
    fields: ({ ruleset, compendium }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'parent', label: 'Belongs to species', type: 'select', options: opts(compendium.species), allowBlank: true },
      ...(ruleset === '2014' ? [{ key: 'abilityBonuses', label: 'Ability score increases', type: 'abilities' }] : []),
      { key: 'traits', label: 'Traits', type: 'rows', columns: traitColumns, blankRow: blankTrait },
      ...effectFields(),
    ],
    validate: (v) => [...needName(v), ...(v.parent ? [] : ['Pick the species it belongs to.'])],
    build: (v, { id, ruleset }) => ({
      subspecies: {
        [id]: {
          name: trim(v.name),
          parent: v.parent,
          traits: cleanRows(v.traits).map((t) => ({ name: trim(t.name), desc: trim(t.desc) })),
          effects: effectsFromValues(v),
          ...(ruleset === '2014' ? { abilityBonuses: cleanBonuses(v.abilityBonuses) } : {}),
        },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, parent: e.parent, abilityBonuses: e.abilityBonuses ?? {},
      traits: e.traits?.length ? e.traits : [blankTrait()], ...effectsToValues(e.effects),
    }),
  },

  background: {
    label: 'Background',
    section: 'backgrounds',
    blank: () => ({
      name: '', skills: [], abilityOptions: [], originFeat: '', featNote: '', tools: '',
      equipment: '', featureName: '', featureDesc: '', gold: '', languagesChoose: 0,
    }),
    fields: ({ ruleset, compendium }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'skills', label: 'Skill proficiencies', type: 'multi', options: skillOpts },
      ...(ruleset === '2024'
        ? [
            { key: 'abilityOptions', label: 'Ability score options (pick 3)', type: 'multi', options: abilityOpts },
            { key: 'originFeat', label: 'Origin feat', type: 'select', options: opts(compendium.feats), allowBlank: true },
            { key: 'featNote', label: 'Feat note (e.g. a spell list)', type: 'text' },
            { key: 'tools', label: 'Tool proficiencies (one per line)', type: 'textarea' },
            { key: 'equipment', label: 'Starting equipment', type: 'textarea' },
          ]
        : [
            { key: 'featureName', label: 'Feature name', type: 'text' },
            { key: 'featureDesc', label: 'Feature description', type: 'textarea' },
            { key: 'languagesChoose', label: 'Languages to choose', type: 'number' },
            { key: 'equipment', label: 'Starting equipment (one per line)', type: 'textarea' },
            { key: 'gold', label: 'Starting gold (e.g. 15 gp)', type: 'text' },
          ]),
    ],
    validate: (v) => needName(v),
    build: (v, { id, ruleset }) => ({
      backgrounds: {
        [id]:
          ruleset === '2024'
            ? {
                name: trim(v.name), abilityOptions: v.abilityOptions ?? [], originFeat: v.originFeat || null,
                featNote: optStr(v.featNote), skills: v.skills ?? [], tools: lines(v.tools), equipment: trim(v.equipment),
              }
            : {
                name: trim(v.name), skills: v.skills ?? [], feature: { name: trim(v.featureName), desc: trim(v.featureDesc) },
                equipment: lines(v.equipment), gold: optStr(v.gold), languagesChoose: num(v.languagesChoose),
              },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, skills: e.skills ?? [], abilityOptions: e.abilityOptions ?? [], originFeat: e.originFeat ?? '',
      featNote: e.featNote ?? '', tools: (e.tools ?? []).join('\n'),
      equipment: Array.isArray(e.equipment) ? e.equipment.join('\n') : (e.equipment ?? ''),
      featureName: e.feature?.name ?? '', featureDesc: e.feature?.desc ?? '', gold: e.gold ?? '',
      languagesChoose: e.languagesChoose ?? 0,
    }),
  },

  feat: {
    label: 'Feat',
    section: 'feats',
    blank: () => ({ name: '', type: 'General', prerequisites: '', desc: '', ...blankEffects() }),
    fields: ({ ruleset }) => [
      { key: 'name', label: 'Name', type: 'text' },
      ...(ruleset === '2024' ? [{ key: 'type', label: 'Type', type: 'select', options: strOpts(FEAT_TYPES) }] : []),
      { key: 'prerequisites', label: 'Prerequisites', type: 'text' },
      { key: 'desc', label: 'Description', type: 'textarea' },
      ...effectFields(true),
    ],
    validate: (v) => needName(v),
    build: (v, { id, ruleset }) => ({
      feats: {
        [id]: {
          name: trim(v.name), desc: trim(v.desc), effects: effectsFromValues(v),
          ...(ruleset === '2024' ? { type: v.type } : {}),
          ...(optStr(v.prerequisites) ? { prerequisites: trim(v.prerequisites) } : {}),
        },
      },
    }),
    fromEntry: (e) => ({ name: e.name, type: e.type ?? 'General', prerequisites: e.prerequisites ?? '', desc: e.desc, ...effectsToValues(e.effects) }),
  },

  class: {
    label: 'Class',
    section: 'classes',
    blank: () => ({
      name: '', hitDie: 8, saves: [], skillChoose: 2, skillFrom: [], proficiencies: '', primaryAbility: '',
      startingEquipment: '', subclassLevel: 3, ...blankCasting(), features: [blankFeature()],
    }),
    fields: ({ ruleset }) => {
      const is2014 = ruleset === '2014'
      const casts = (v) => v.castType !== 'none'
      return [
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'hitDie', label: 'Hit die', type: 'select', options: [6, 8, 10, 12].map((n) => ({ value: n, label: `d${n}` })), number: true },
        { key: 'saves', label: 'Saving throw proficiencies (pick 2)', type: 'multi', options: abilityOpts },
        { key: 'skillChoose', label: 'Number of skills to choose', type: 'number' },
        { key: 'skillFrom', label: 'Skills to choose from', type: 'multi', options: skillOpts },
        { key: 'proficiencies', label: 'Armor, weapon and tool proficiencies (one per line)', type: 'textarea', help: 'Use "Simple Weapons" / "Martial Weapons" so attacks get the proficiency bonus.' },
        ...(ruleset === '2024' ? [{ key: 'primaryAbility', label: 'Primary ability (text)', type: 'text' }] : []),
        { key: 'startingEquipment', label: 'Starting equipment (one per line)', type: 'textarea' },
        { key: 'subclassLevel', label: 'Subclass level', type: 'number', min: 1, max: 20 },
        { key: 'castType', label: 'Spellcasting', type: 'select', options: [
          { value: 'none', label: 'None' }, { value: 'full', label: 'Full caster slots (wizard-style)' },
          { value: 'half', label: 'Half caster slots (paladin-style)' }, { value: 'pact', label: 'Pact magic (warlock-style)' },
        ] },
        { key: 'castAbility', label: 'Spellcasting ability', type: 'select', options: abilityOpts, show: casts },
        ...(is2014
          ? [
              { key: 'castMode', label: 'Spells', type: 'select', options: [{ value: 'prepared', label: 'Prepared from the class list' }, { value: 'known', label: 'A fixed number known' }], show: casts },
              { key: 'preparedFormula', label: 'Prepared = ability mod +', type: 'select', options: [{ value: 'full', label: 'class level' }, { value: 'half', label: 'half class level' }], show: (v) => casts(v) && v.castMode === 'prepared' },
              { key: 'known1', label: 'Spells known at first casting level', type: 'number', show: (v) => casts(v) && v.castMode === 'known' },
              { key: 'knownPerLevel', label: 'Extra known spells per level', type: 'number', show: (v) => casts(v) && v.castMode === 'known' },
            ]
          : [
              { key: 'prepared1', label: 'Prepared spells at first casting level', type: 'number', show: casts },
              { key: 'preparedPerLevel', label: 'Extra prepared spells per level', type: 'number', show: casts },
            ]),
        { key: 'spellbook', label: 'Uses a spellbook', type: 'checkbox', show: casts },
        { key: 'startLevel', label: 'First casting level (blank = automatic)', type: 'number', show: casts },
        { key: 'cantrips1', label: 'Cantrips known, levels 1-3', type: 'number', show: casts },
        { key: 'cantrips4', label: 'Cantrips known, levels 4-9', type: 'number', show: casts },
        { key: 'cantrips10', label: 'Cantrips known, level 10+', type: 'number', show: casts },
        { key: 'features', label: 'Class features', type: 'rows', columns: featureColumns, blankRow: blankFeature },
      ]
    },
    validate: (v) => [
      ...needName(v),
      ...(v.saves.length !== 2 ? ['Pick exactly two saving throws.'] : []),
      ...(num(v.skillChoose) > v.skillFrom.length ? ['You can\'t choose more skills than you listed.'] : []),
    ],
    build: (v, { id, ruleset }) => {
      const { features, ids } = makeFeatures(v.features, id, { class: id })
      const levels = {}
      for (let l = 1; l <= 20; l++) levels[l] = { prof: proficiencyBonus(l), features: [], specific: {} }
      ids.forEach((fid) => levels[features[fid].level].features.push(fid))
      return {
        classes: {
          [id]: {
            name: trim(v.name),
            hitDie: num(v.hitDie, 8),
            saves: v.saves,
            skillChoices: { choose: num(v.skillChoose), from: v.skillFrom },
            proficiencies: lines(v.proficiencies),
            startingEquipment: lines(v.startingEquipment),
            spellcasting: makeSpellcasting(v, ruleset),
            levels,
            subclasses: [],
            subclassLevel: clamp(num(v.subclassLevel, 3), 1, 20),
            ...(ruleset === '2024' && optStr(v.primaryAbility) ? { primaryAbility: trim(v.primaryAbility) } : {}),
            editor: { casting: Object.fromEntries(CASTING_KEYS.map((k) => [k, v[k]])) },
          },
        },
        features,
      }
    },
    fromEntry: (e, _ctx, content) => {
      const rows = []
      for (let l = 1; l <= 20; l++) {
        for (const fid of e.levels?.[l]?.features ?? []) {
          const f = content.features?.[fid]
          if (f) rows.push({ level: f.level, name: f.name, desc: f.desc })
        }
      }
      return {
        name: e.name, hitDie: e.hitDie, saves: e.saves, skillChoose: e.skillChoices?.choose ?? 0,
        skillFrom: e.skillChoices?.from ?? [], proficiencies: (e.proficiencies ?? []).join('\n'),
        primaryAbility: e.primaryAbility ?? '', startingEquipment: (e.startingEquipment ?? []).join('\n'),
        subclassLevel: e.subclassLevel ?? 3, ...blankCasting(), ...(e.editor?.casting ?? {}),
        features: rows.length ? rows : [blankFeature()],
      }
    },
    owned: (e) => Object.values(e.levels ?? {}).flatMap((l) => l.features ?? []),
  },

  subclass: {
    label: 'Subclass',
    section: 'subclasses',
    blank: () => ({ name: '', class: '', flavor: '', desc: '', features: [{ level: 3, name: '', desc: '' }] }),
    fields: ({ compendium }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'class', label: 'Belongs to class', type: 'select', options: opts(compendium.classes), allowBlank: true },
      { key: 'flavor', label: 'Short summary', type: 'text' },
      { key: 'desc', label: 'Description', type: 'textarea' },
      { key: 'features', label: 'Subclass features', type: 'rows', columns: featureColumns, blankRow: blankFeature },
    ],
    validate: (v) => [...needName(v), ...(v.class ? [] : ['Pick the class it belongs to.'])],
    build: (v, { id }) => {
      const { features, ids } = makeFeatures(v.features, id, { class: v.class, subclass: id })
      return {
        subclasses: { [id]: { name: trim(v.name), class: v.class, flavor: trim(v.flavor), desc: trim(v.desc), features: ids } },
        features,
      }
    },
    fromEntry: (e, _ctx, content) => ({
      name: e.name, class: e.class, flavor: e.flavor ?? '', desc: e.desc ?? '',
      features: (e.features ?? []).map((fid) => content.features?.[fid]).filter(Boolean)
        .map((f) => ({ level: f.level, name: f.name, desc: f.desc })),
    }),
    owned: (e) => e.features ?? [],
  },

  weapon: {
    label: 'Weapon',
    section: 'weapons',
    blank: () => ({
      name: '', category: 'martial', range: 'melee', damage: '1d8', damageType: 'Slashing', properties: [],
      versatileDamage: '', rangeNormal: '', rangeLong: '', mastery: '', weight: '', cost: '',
    }),
    fields: ({ ruleset }) => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'category', label: 'Category', type: 'select', options: strOpts(['simple', 'martial']) },
      { key: 'range', label: 'Melee or ranged', type: 'select', options: strOpts(['melee', 'ranged']) },
      { key: 'damage', label: 'Damage dice', type: 'text', help: 'e.g. 1d8, or just 1' },
      { key: 'damageType', label: 'Damage type', type: 'text' },
      { key: 'properties', label: 'Properties', type: 'multi', options: strOpts(WEAPON_PROPERTIES) },
      { key: 'versatileDamage', label: 'Two-handed damage (versatile)', type: 'text' },
      { key: 'rangeNormal', label: 'Normal range (ft)', type: 'number' },
      { key: 'rangeLong', label: 'Long range (ft)', type: 'number' },
      ...(ruleset === '2024' ? [{ key: 'mastery', label: 'Mastery property', type: 'text' }] : []),
      { key: 'weight', label: 'Weight (lb)', type: 'number' },
      { key: 'cost', label: 'Cost (e.g. 15 gp)', type: 'text' },
    ],
    validate: (v) => [
      ...needName(v),
      ...(/^\d+(d\d+)?$/.test(trim(v.damage)) ? [] : ['Damage must look like 1d8 (or a flat number).']),
      ...(trim(v.versatileDamage) && !/^\d+d\d+$/.test(trim(v.versatileDamage)) ? ['Two-handed damage must look like 1d10.'] : []),
    ],
    build: (v, { id, ruleset }) => ({
      weapons: {
        [id]: {
          name: trim(v.name), category: v.category, range: v.range, damage: trim(v.damage),
          damageType: trim(v.damageType) || 'Slashing', properties: v.properties ?? [],
          ...(trim(v.versatileDamage) ? { versatileDamage: trim(v.versatileDamage) } : {}),
          rangeNormal: v.rangeNormal === '' ? null : num(v.rangeNormal), rangeLong: v.rangeLong === '' ? null : num(v.rangeLong),
          ...(ruleset === '2024' && optStr(v.mastery) ? { mastery: trim(v.mastery) } : {}),
          weight: v.weight === '' ? null : num(v.weight), cost: optStr(v.cost),
        },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, category: e.category, range: e.range, damage: e.damage, damageType: e.damageType,
      properties: e.properties ?? [], versatileDamage: e.versatileDamage ?? '', rangeNormal: e.rangeNormal ?? '',
      rangeLong: e.rangeLong ?? '', mastery: e.mastery ?? '', weight: e.weight ?? '', cost: e.cost ?? '',
    }),
  },

  armor: {
    label: 'Armor / shield',
    section: 'armor',
    blank: () => ({ name: '', category: 'light', baseAc: 11, strMin: 0, stealthDisadvantage: false, weight: '', cost: '' }),
    fields: () => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'category', label: 'Category', type: 'select', options: strOpts(['light', 'medium', 'heavy', 'shield']) },
      { key: 'baseAc', label: 'Base AC (a shield\'s AC bonus)', type: 'number' },
      { key: 'strMin', label: 'Strength required', type: 'number' },
      { key: 'stealthDisadvantage', label: 'Stealth disadvantage', type: 'checkbox' },
      { key: 'weight', label: 'Weight (lb)', type: 'number' },
      { key: 'cost', label: 'Cost (e.g. 50 gp)', type: 'text' },
    ],
    validate: (v) => [...needName(v), ...(num(v.baseAc) > 0 ? [] : ['Base AC must be above 0.'])],
    build: (v, { id }) => ({
      armor: {
        [id]: {
          name: trim(v.name), category: v.category, baseAc: num(v.baseAc),
          ...(v.category === 'shield' ? { acBonus: num(v.baseAc) } : {}),
          strMin: num(v.strMin), stealthDisadvantage: !!v.stealthDisadvantage,
          weight: v.weight === '' ? null : num(v.weight), cost: optStr(v.cost),
        },
      },
    }),
    fromEntry: (e) => ({
      name: e.name, category: e.category, baseAc: e.baseAc, strMin: e.strMin ?? 0,
      stealthDisadvantage: !!e.stealthDisadvantage, weight: e.weight ?? '', cost: e.cost ?? '',
    }),
  },

  gear: {
    label: 'Gear',
    section: 'gear',
    blank: () => ({ name: '', category: 'Adventuring Gear', weight: '', cost: '', desc: '' }),
    fields: () => [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'category', label: 'Category', type: 'text' },
      { key: 'weight', label: 'Weight (lb)', type: 'number' },
      { key: 'cost', label: 'Cost (e.g. 5 gp)', type: 'text' },
      { key: 'desc', label: 'Description', type: 'textarea' },
    ],
    validate: (v) => needName(v),
    build: (v, { id }) => ({
      gear: {
        [id]: {
          name: trim(v.name), category: trim(v.category) || 'Gear',
          weight: v.weight === '' ? null : num(v.weight), cost: optStr(v.cost),
          ...(trim(v.desc) ? { desc: trim(v.desc) } : {}),
        },
      },
    }),
    fromEntry: (e) => ({ name: e.name, category: e.category, weight: e.weight ?? '', cost: e.cost ?? '', desc: e.desc ?? '' }),
  },
}

export const KIND_ORDER = ['spell', 'species', 'subspecies', 'background', 'feat', 'class', 'subclass', 'weapon', 'armor', 'gear']
